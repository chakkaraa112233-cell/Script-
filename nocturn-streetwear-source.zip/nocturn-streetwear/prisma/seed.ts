import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

async function main() {
  const products = [
    {name:"AFTERHOURS OVERSIZED TEE", slug:"afterhours-oversized-tee", description:"Heavyweight streetwear tee. Relaxed fit, everyday uniform.", category:"T-SHIRTS", price:899, compareAt:1199, image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=85", sizes:"S,M,L,XL", stock:25, featured:true, active:true},
    {name:"VOID HEAVYWEIGHT HOODIE", slug:"void-heavyweight-hoodie", description:"A clean, structured layer for colder nights.", category:"HOODIES", price:1799, compareAt:2199, image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=85", sizes:"S,M,L,XL", stock:12, featured:true, active:true},
    {name:"NO SIGNAL GRAPHIC TEE", slug:"no-signal-graphic-tee", description:"Minimal front. Statement back. Limited drop.", category:"T-SHIRTS", price:999, image:"https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=900&q=85", sizes:"S,M,L,XL", stock:18, featured:false, active:true},
    {name:"UTILITY CARGO PANTS", slug:"utility-cargo-pants", description:"Utility-inspired silhouette with a relaxed profile.", category:"BOTTOMS", price:1599, image:"https://images.unsplash.com/photo-1517365830460-955ce3ccd263?auto=format&fit=crop&w=900&q=85", sizes:"S,M,L,XL", stock:9, featured:true, active:true}
  ];
  for (const p of products) {
    await db.product.upsert({where:{slug:p.slug}, update:{}, create:p});
  }
  console.log("Seed products added.");
}
main().finally(()=>db.$disconnect());