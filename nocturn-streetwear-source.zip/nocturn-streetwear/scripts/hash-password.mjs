import bcrypt from "bcryptjs";
const password = process.argv[2];
if (!password || password.length < 12) {
  console.error('Usage: npm run admin:hash -- "A-strong-password-12+"');
  console.error("Use at least 12 characters.");
  process.exit(1);
}
console.log(await bcrypt.hash(password, 12));