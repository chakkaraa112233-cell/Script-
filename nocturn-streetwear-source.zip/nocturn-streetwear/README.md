# NOCTURN-style Streetwear Store (Next.js + Prisma + SQLite)

A mobile-first starter storefront with product listing/search/category filtering, product detail pages, local cart, COD checkout, stock validation, admin login, product management, and order status management. The visual direction is black/charcoal, editorial, and minimalist; it is inspired by a general streetwear aesthetic, not a copy of another store's proprietary source code.

## Requirements
- Node.js 20.9+ (Node 22 LTS recommended)
- npm
- For local development, SQLite is used so no separate database server is needed.

## 1. Create environment file
Copy `.env.example` to `.env`. Replace `SESSION_SECRET` with a random secret of at least 32 characters. Change `ADMIN_EMAIL` and choose a strong admin password.

Generate a bcrypt hash:
```bash
npm install
npm run admin:hash -- "Use-A-Strong-Password-Here"
```
Copy the printed hash into `.env` as `ADMIN_PASSWORD_HASH="..."`. You can remove the unused `ADMIN_PASSWORD` line from `.env`; the app checks only `ADMIN_PASSWORD_HASH`. The raw password is not stored in the database or committed source code. `.env` must never be uploaded to a public repository.

## 2. Setup database and sample products
```bash
npx prisma generate
npm run db:push
npm run db:seed
```

## 3. Start locally
```bash
npm run dev
```
Open `http://localhost:3000`. Shop: `/shop`. Admin: `/admin/login`.

## Android (Termux)
1. Install Termux from its official F-Droid/GitHub source.
2. In Termux run:
```bash
pkg update && pkg upgrade
pkg install nodejs-lts git nano
node -v
npm -v
```
3. Transfer/extract this ZIP into Termux storage or clone your private repository. If transferring via Android shared storage, run `termux-setup-storage` and unzip from the Downloads folder. Example:
```bash
termux-setup-storage
cd ~/storage/downloads
unzip nocturn-streetwear.zip
cd nocturn-streetwear
cp .env.example .env
nano .env
```
4. Edit `.env`; create a random `SESSION_SECRET` and set `ADMIN_EMAIL`. Generate a password hash as described above, then add `ADMIN_PASSWORD_HASH` to `.env`.
5. Run the database setup and development server commands above. Open `http://localhost:3000` in your phone browser.
6. Keep Termux running while testing locally. This is a local development server, not a public website.

If `nodejs-lts` is unavailable on your Termux mirror, run `pkg search nodejs` and install the current supported Node package. Next.js development on Android can be slower and some phones may run out of memory.

## Deploying publicly
For production, use a Node-compatible host (for example, a Next.js hosting provider) and a managed PostgreSQL database. Change the Prisma datasource provider to `postgresql`, use `DATABASE_URL` from the provider, and run `npx prisma generate` plus `npx prisma migrate deploy` during deployment. This starter schema is configured for SQLite local development; do not use a local SQLite file for a multi-instance production deployment. Add a migration workflow before production.

## Included routes
- `/` storefront homepage
- `/shop` searchable/filterable product grid
- `/product/[slug]` product detail + size selection
- `/cart` local browser cart
- `/checkout` guest COD checkout
- `/admin/login` admin login
- `/admin` admin dashboard/products/orders
- `/api/orders` server-priced order creation and stock check
- `/api/admin/*` admin-only catalog and order endpoints

## Important before taking real orders
- Add your real store name, product photography, support email, return/shipping policies and legal pages.
- Configure HTTPS and secure deployment environment variables.
- Add rate limiting / bot protection, CSRF strategy appropriate to your deployment, backups, and order notifications.
- Online payments are not included. COD only is enabled; integrate a payment provider and verify webhooks server-side before enabling online payments.
- This is a starter codebase. Test checkout, inventory, and admin access before launch. Do not store card details yourself.
