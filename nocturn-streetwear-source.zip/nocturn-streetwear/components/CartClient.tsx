 "use client";
import {useEffect,useState} from "react";
type Item={id:string;name:string;slug:string;price:number;image:string;size:string;quantity:number;stock:number};
export default function CartClient(){
 const [items,setItems]=useState<Item[]>([]);const [ready,setReady]=useState(false);
 function load(){try{setItems(JSON.parse(localStorage.getItem("nocturn-cart")||"[]"))}catch{setItems([])}setReady(true)}
 useEffect(()=>{load();window.addEventListener("nocturn-cart-updated",load);return()=>window.removeEventListener("nocturn-cart-updated",load)},[]);
 function save(next:Item[]){setItems(next);localStorage.setItem("nocturn-cart",JSON.stringify(next))}
 const total=items.reduce((s,i)=>s+i.price*i.quantity,0);
 if(!ready)return <p className="muted">Loading bag...</p>;
 if(!items.length)return <div className="empty"><p>YOUR BAG IS EMPTY.</p><a className="btn" href="/shop">SHOP THE DROP</a></div>;
 return <div className="two-col" style={{alignItems:"start"}}><section>{items.map(i=><div className="cart-row" key={i.id+i.size}>{i.image&&<img src={i.image} alt={i.name}/>}<div><b style={{fontSize:11}}>{i.name}</b><p className="muted mono" style={{fontSize:10}}>SIZE: {i.size}</p><p>₹{i.price.toLocaleString("en-IN")}</p><div className="qty"><button onClick={()=>save(items.map(x=>x===i?{...x,quantity:Math.max(1,x.quantity-1)}:x))}>−</button><span>{i.quantity}</span><button onClick={()=>save(items.map(x=>x===i?{...x,quantity:Math.min(x.stock,x.quantity+1)}:x))}>+</button><button className="small-btn" onClick={()=>save(items.filter(x=>x!==i))}>REMOVE</button></div></div><b>₹{(i.price*i.quantity).toLocaleString("en-IN")}</b></div>)}</section><aside className="panel"><div className="eyebrow mono">ORDER SUMMARY</div><h2>₹{total.toLocaleString("en-IN")}</h2><p className="muted" style={{fontSize:12}}>Shipping is ₹99 for orders under ₹1,999. Free above ₹1,999.</p><a className="btn" style={{width:"100%"}} href="/checkout">CHECKOUT ↗</a><p className="muted" style={{fontSize:10}}>Secure your selection while stocks last.</p></aside></div>
}