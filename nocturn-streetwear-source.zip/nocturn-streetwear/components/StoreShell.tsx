import Link from "next/link";
export function Header({count=0}:{count?:number}) {
  return <><div className="announcement mono">FREE SHIPPING ON ORDERS OVER ₹1,999 — LIMITED DROP</div><header className="wrap nav"><Link href="/" className="logo">NOCTURN<span style={{color:"#777"}}>®</span></Link><nav className="navlinks mono"><Link href="/shop">SHOP ALL</Link><a href="/#story">ABOUT</a><a href="/#footer">INFO</a></nav><div className="navright mono"><Link href="/shop">SEARCH</Link><Link href="/cart">BAG ({count})</Link></div></header></>;
}
export function Footer(){return <footer id="footer" className="footer"><div className="wrap"><div className="footer-row"><div><div className="logo" style={{color:"#eee",fontSize:17}}>NOCTURN®</div><p className="mono">INDEPENDENT STREETWEAR / INDIA</p></div><div><p>Shipping & Returns</p><p>Contact: support@example.com</p><p className="mono">© {new Date().getFullYear()} NOCTURN. ALL RIGHTS RESERVED.</p></div></div></div></footer>}
export function Money({value}:{value:number}){return <span>₹{value.toLocaleString("en-IN")}</span>}
