 "use client";
import {useState} from "react";
type Item={id:string;name:string;price:number;size:string;quantity:number};
export default function CheckoutClient(){
 const [busy,setBusy]=useState(false);const [msg,setMsg]=useState("");const [order,setOrder]=useState("");
 async function submit(e:React.FormEvent<HTMLFormElement>){e.preventDefault();setBusy(true);setMsg("");
  const items=JSON.parse(localStorage.getItem("nocturn-cart")||"[]") as Item[];
  if(!items.length){setMsg("Your bag is empty.");setBusy(false);return}
  const fd=new FormData(e.currentTarget);const payload={customerName:fd.get("name"),email:fd.get("email"),phone:fd.get("phone"),address:fd.get("address"),city:fd.get("city"),state:fd.get("state"),pincode:fd.get("pincode"),notes:fd.get("notes"),items:items.map(i=>({productId:i.id,size:i.size,quantity:i.quantity}))};
  const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const data=await res.json();setBusy(false);
  if(!res.ok){setMsg(data.error||"Could not place order.");return}
  localStorage.removeItem("nocturn-cart");setOrder(data.orderNumber);setMsg("Order placed successfully.");
 }
 if(order)return <div className="panel"><div className="eyebrow mono">ORDER CONFIRMED</div><h2>THANK YOU.</h2><p>Your order number is <b>{order}</b>.</p><p className="muted">Payment method: Cash on Delivery. Keep this order number for support.</p><a href="/shop" className="btn">CONTINUE SHOPPING</a></div>;
 return <div className="two-col" style={{alignItems:"start"}}><form className="panel" onSubmit={submit}><h2>Delivery details</h2><div className="form-grid">{[["name","Full name","text"],["email","Email","email"],["phone","Phone number","tel"],["pincode","PIN code","text"],["city","City / Town","text"],["state","State","text"]].map(([name,label,type])=><div key={name}><label className="field-label">{label.toUpperCase()}</label><input className="field" name={name} type={type} required maxLength={name==="phone"?15:100}/></div>)}</div><label className="field-label">FULL ADDRESS</label><textarea className="field" name="address" rows={3} required maxLength={500}/><label className="field-label">ORDER NOTES (OPTIONAL)</label><textarea className="field" name="notes" rows={2} maxLength={500}/><p className="muted" style={{fontSize:11}}>Payment: Cash on Delivery (COD). Online payment is not configured.</p><button className="btn" disabled={busy}>{busy?"PLACING ORDER...":"PLACE COD ORDER ↗"}</button>{msg&&<p className="notice">{msg}</p>}</form><aside className="panel"><div className="eyebrow mono">CHECKOUT NOTE</div><h2>NO SURPRISES.</h2><p className="muted" style={{fontSize:12,lineHeight:1.8}}>Your order total is calculated on the server using current product prices. Shipping is ₹99 below ₹1,999 and free at or above ₹1,999.</p></aside></div>
}