 "use client";
import {useState} from "react";
type P={id:string;name:string;slug:string;price:number;image:string;sizes:string[];stock:number};
export default function AddToCart({product}:{product:P}){
 const [size,setSize]=useState(product.sizes[0]||"One Size"); const [message,setMessage]=useState("");
 function add(){if(product.stock<1){setMessage("This piece is currently sold out.");return}
  const cart=JSON.parse(localStorage.getItem("nocturn-cart")||"[]") as any[];
  const old=cart.find(x=>x.id===product.id&&x.size===size);
  if(old)old.quantity=Math.min(old.quantity+1,product.stock);else cart.push({...product,size,quantity:1});
  localStorage.setItem("nocturn-cart",JSON.stringify(cart));setMessage("Added to bag.");window.dispatchEvent(new Event("nocturn-cart-updated"));
 }
 return <><div className="size-options">{product.sizes.map(s=><button key={s} className={`size-btn ${s===size?"active":""}`} onClick={()=>setSize(s)}>{s}</button>)}</div><button className="btn" style={{width:"100%"}} onClick={add} disabled={product.stock<1}>{product.stock>0?"ADD TO BAG — ₹"+product.price.toLocaleString("en-IN"):"SOLD OUT"}</button>{message&&<p className="notice">{message} <a href="/cart" style={{textDecoration:"underline"}}>View bag ↗</a></p>}</>;
}