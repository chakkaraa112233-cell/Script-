import {Header,Footer} from "@/components/StoreShell";
import CartClient from "@/components/CartClient";
export default function Cart(){return <><Header/><main className="wrap"><div className="page-title"><div className="eyebrow mono">YOUR SELECTION</div><h1>THE BAG.</h1></div><CartClient/></main><Footer/></>}