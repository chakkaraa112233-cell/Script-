import {NextResponse} from "next/server";
import bcrypt from "bcryptjs";
import {createAdminSession} from "@/lib/auth";
export async function POST(req:Request){
 try{const b=await req.json();const email=String(b.email||"").trim().toLowerCase();const password=String(b.password||"");
 const configuredEmail=(process.env.ADMIN_EMAIL||"").trim().toLowerCase();const hash=process.env.ADMIN_PASSWORD_HASH;
 if(!configuredEmail||!hash||email!==configuredEmail||!(await bcrypt.compare(password,hash)))return NextResponse.json({error:"Invalid admin credentials."},{status:401});
 await createAdminSession(email);return NextResponse.json({ok:true});
 }catch{return NextResponse.json({error:"Login is not configured. Check environment variables."},{status:500})}
}