import {NextResponse} from "next/server";
import {db} from "@/lib/prisma";
import {isAdmin} from "@/lib/auth";
const statuses=["PENDING","CONFIRMED","PACKED","SHIPPED","DELIVERED","CANCELLED"];
export async function PATCH(req:Request,{params}:{params:Promise<{id:string}>}){if(!(await isAdmin()))return NextResponse.json({error:"Unauthorized"},{status:401});const {id}=await params;const b=await req.json();if(!statuses.includes(b.status))return NextResponse.json({error:"Invalid status"},{status:400});try{return NextResponse.json(await db.order.update({where:{id},data:{status:b.status}}))}catch{return NextResponse.json({error:"Order not found"},{status:404})}}