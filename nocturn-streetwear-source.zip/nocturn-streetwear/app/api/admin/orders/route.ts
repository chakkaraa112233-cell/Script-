import {NextResponse} from "next/server";
import {db} from "@/lib/prisma";
import {isAdmin} from "@/lib/auth";
export async function GET(){if(!(await isAdmin()))return NextResponse.json({error:"Unauthorized"},{status:401});const orders=await db.order.findMany({include:{items:true},orderBy:{createdAt:"desc"},take:200});return NextResponse.json(orders)}