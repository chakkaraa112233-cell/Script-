import {NextResponse} from "next/server";
import {db} from "@/lib/prisma";
import {isAdmin} from "@/lib/auth";
const valid=(b:any)=>typeof b.name==="string"&&b.name.trim()&&typeof b.slug==="string"&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(b.slug)&&Number.isInteger(b.price)&&b.price>=1&&b.price<=10000000&&Number.isInteger(b.stock)&&b.stock>=0&&b.stock<=1000000;
export async function GET(){if(!(await isAdmin()))return NextResponse.json({error:"Unauthorized"},{status:401});return NextResponse.json(await db.product.findMany({orderBy:{createdAt:"desc"}}))}
export async function POST(req:Request){if(!(await isAdmin()))return NextResponse.json({error:"Unauthorized"},{status:401});try{const b=await req.json();if(!valid(b))return NextResponse.json({error:"Name, valid slug, price and stock are required."},{status:400});
 const p=await db.product.create({data:{name:b.name.trim().slice(0,150),slug:b.slug,description:String(b.description||"").slice(0,2000),category:String(b.category||"T-SHIRTS").slice(0,80),price:b.price,compareAt:Number.isInteger(b.compareAt)&&b.compareAt>0?b.compareAt:null,image:String(b.image||"").slice(0,1500),sizes:String(b.sizes||"S,M,L,XL").slice(0,100),stock:b.stock,featured:!!b.featured,active:b.active!==false}});return NextResponse.json(p,{status:201});
 }catch{return NextResponse.json({error:"Could not create product. Slug may already exist."},{status:400})}}
