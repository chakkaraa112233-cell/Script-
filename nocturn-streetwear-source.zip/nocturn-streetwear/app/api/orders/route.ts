import { NextResponse } from "next/server";
import { db } from "@/lib/prisma";
export const runtime="nodejs";
export async function POST(req:Request){
 try{
  const b=await req.json();
  const required=["customerName","email","phone","address","city","state","pincode"];
  for(const k of required)if(typeof b[k]!=="string"||!b[k].trim())return NextResponse.json({error:`Please provide ${k}.`},{status:400});
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email)||b.email.length>200)return NextResponse.json({error:"Enter a valid email."},{status:400});
  if(b.phone.length>20||b.pincode.length>12||b.address.length>500)return NextResponse.json({error:"Please check your delivery details."},{status:400});
  if(!Array.isArray(b.items)||b.items.length<1||b.items.length>30)return NextResponse.json({error:"Your bag is empty or too large."},{status:400});
  const ids=[...new Set(b.items.map((i:any)=>i.productId))];
  const products=await db.product.findMany({where:{id:{in:ids},active:true}});
  let subtotal=0;const lines:any[]=[];
  for(const item of b.items){
   if(!Number.isInteger(item.quantity)||item.quantity<1||item.quantity>10)return NextResponse.json({error:"Invalid quantity."},{status:400});
   const p=products.find(x=>x.id===item.productId);
   if(!p||p.stock<item.quantity)return NextResponse.json({error:`${p?.name||"A product"} is unavailable in the requested quantity.`},{status:409});
   const sizes=p.sizes.split(",").map(s=>s.trim());
   if(typeof item.size!=="string"||!sizes.includes(item.size))return NextResponse.json({error:"Please select a valid size."},{status:400});
   subtotal+=p.price*item.quantity;lines.push({productId:p.id,name:p.name,price:p.price,size:item.size,quantity:item.quantity});
  }
  const shipping=subtotal>=1999?0:99;const orderNumber="NC-"+Date.now().toString().slice(-8);
  const result=await db.$transaction(async tx=>{
   for(const item of lines){const changed=await tx.product.updateMany({where:{id:item.productId,stock:{gte:item.quantity}},data:{stock:{decrement:item.quantity}}});if(changed.count!==1)throw new Error("STOCK_CHANGED");}
   return tx.order.create({data:{orderNumber,customerName:b.customerName.trim().slice(0,100),email:b.email.trim().toLowerCase(),phone:b.phone.trim(),address:b.address.trim(),city:b.city.trim().slice(0,100),state:String(b.state).trim().slice(0,100),pincode:b.pincode.trim(),notes:typeof b.notes==="string"?b.notes.trim().slice(0,500):"",subtotal,shipping,total:subtotal+shipping,paymentStatus:"COD",items:{create:lines}}});
  });
  return NextResponse.json({orderNumber:result.orderNumber,total:result.total},{status:201});
 }catch(e){if(e instanceof Error&&e.message==="STOCK_CHANGED")return NextResponse.json({error:"Stock changed. Please refresh your bag."},{status:409});return NextResponse.json({error:"Unable to place order. Please try again."},{status:500})}
}