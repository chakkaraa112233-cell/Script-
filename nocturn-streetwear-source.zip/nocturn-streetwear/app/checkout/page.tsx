import {Header,Footer} from "@/components/StoreShell";
import CheckoutClient from "@/components/CheckoutClient";
export default function Checkout(){return <><Header/><main className="wrap"><div className="page-title"><div className="eyebrow mono">ALMOST YOURS</div><h1>CHECKOUT.</h1></div><CheckoutClient/></main><Footer/></>}