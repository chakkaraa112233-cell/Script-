import { notFound } from "next/navigation";
import { db } from "@/lib/prisma";
import { Header, Footer, Money } from "@/components/StoreShell";
import AddToCart from "@/components/AddToCart";
export const dynamic="force-dynamic";
export default async function ProductPage({params}:{params:Promise<{slug:string}>}){
 const {slug}=await params; const p=await db.product.findUnique({where:{slug}});
 if(!p||!p.active)notFound();
 return <><Header/><main className="wrap"><div className="detail-grid"><div>{p.image&&<img className="detail-img" src={p.image} alt={p.name}/>}</div><div style={{paddingTop:12}}><div className="eyebrow mono">NOCTURN® / {p.category}</div><h1 style={{fontSize:"clamp(30px,5vw,54px)",lineHeight:1.05,letterSpacing:-2}}>{p.name}</h1><div className="price" style={{fontSize:17,margin:"18px 0"}}><Money value={p.price}/>{p.compareAt&&<span className="old-price"><Money value={p.compareAt}/></span>}</div><p className="muted" style={{fontSize:13,lineHeight:1.9}}>{p.description}</p><p className="mono" style={{fontSize:10,marginTop:25}}>SELECT SIZE</p><AddToCart product={{id:p.id,name:p.name,slug:p.slug,price:p.price,image:p.image,sizes:p.sizes.split(",").map(s=>s.trim()),stock:p.stock}}/><p className="muted" style={{fontSize:11,lineHeight:1.9,marginTop:25}}>Shipping calculated at checkout. Cash on delivery is available in this starter build. Keep the product in original condition for eligible returns.</p></div></div></main><Footer/></>;
}