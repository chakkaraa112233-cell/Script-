import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "NOCTURN® — AFTERHOURS", description: "Independent streetwear. Limited drops. Built for afterhours." };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}